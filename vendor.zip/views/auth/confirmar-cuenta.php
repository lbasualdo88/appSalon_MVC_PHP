<h1 class="nombre-pagina">Confirmar Cuenta</h1>

<?php include_once __DIR__ . '/../templates/alertas.php'; ?>

<div class="acciones">
    <a href="/">Iniciar Sesión</a>
</div>